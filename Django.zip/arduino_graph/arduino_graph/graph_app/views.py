from django.shortcuts import render
import serial

def graph_view(request):
    arduino_port = '/dev/cu.usbserial-14130'  # Update with your Arduino's port
    baud_rate = 115200  # Update with your Arduino's baud rate

    # Establish a connection with the Arduino
    arduino = serial.Serial(arduino_port, baud_rate, timeout=1)

    # Read data from the Arduino's Serial Monitor
    line = arduino.readline().decode().strip()
    vnet = float(line)

    context = {
        'vnet': vnet,
    }

    return render(request, 'graph.html', context)