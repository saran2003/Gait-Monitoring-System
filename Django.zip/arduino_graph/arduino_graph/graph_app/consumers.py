import json
from channels.generic.websocket import AsyncWebsocketConsumer

class YourConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()

    async def disconnect(self, close_code):
        pass

    async def receive(self, text_data):
        # You can handle WebSocket messages here
        # For example, you can receive data from the client and send it back
        data = json.loads(text_data)
        message = data.get('message')

        # Echo the message back to the client
        await self.send(text_data=json.dumps({
            'message': message
        }))